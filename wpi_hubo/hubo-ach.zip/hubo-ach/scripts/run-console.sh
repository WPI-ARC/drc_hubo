sudo ./hubo-console
