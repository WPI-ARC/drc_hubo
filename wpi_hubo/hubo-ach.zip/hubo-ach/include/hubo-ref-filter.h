/* -*-	indent-tabs-mode:t; tab-width: 8; c-basic-offset: 8  -*- */
#include <stdint.h>

#define buffLength 50
#define buffLength2 50
