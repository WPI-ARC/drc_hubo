rosbag record -a
